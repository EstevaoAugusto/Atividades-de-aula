package uso_aula2;


public class Uso_Aula2 {    
    
    public static void main(String[] args) {
        
        
    }
}
