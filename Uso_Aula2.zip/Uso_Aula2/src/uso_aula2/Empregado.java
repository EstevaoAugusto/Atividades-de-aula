package uso_aula2;


public abstract class Empregado {
    
    private String primeiroNome;
    private String segundoNome;
    private String numeroSegSocial;

    public String getPrimeiroNome() {
        return primeiroNome;
    }

    public void setPrimeiroNome(String primeiroNome) {
        this.primeiroNome = primeiroNome;
    }

    public String getSegundoNome() {
        return segundoNome;
    }

    public void setSegundoNome(String segundoNome) {
        this.segundoNome = segundoNome;
    }

    public String getNumeroSegSocial() {
        return numeroSegSocial;
    }

    public void setNumeroSegSocial(String numeroSegSocial) {
        this.numeroSegSocial = numeroSegSocial;
    }
    
    
    
    @Override
    public String toString(){
        return "Nome Completo"+ this.primeiroNome +" "+ this.segundoNome + "\n"
                + "Numero Seguridade Social"+ this.numeroSegSocial;
    }
    
    /*Toda Clsse "abstract" precisa ter um método abstrato
    Método abstrato é aquele que só tem a assinatura, ou seja,
    não código implementado
    */
    public abstract double ganhoSalarial();
}