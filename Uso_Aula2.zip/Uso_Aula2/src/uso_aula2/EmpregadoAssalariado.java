package uso_aula2;


public class EmpregadoAssalariado extends Empregado{
    private double salarioSemanal;

    public double getSalarioSemanal() {
        return salarioSemanal;
    }

    public void setSalarioSemanal(double salarioSemanal) {
        this.salarioSemanal = salarioSemanal;
    }
    
    
    
    @Override
    public double ganhoSalarial(){
        //retornar o salario do empregado após 4 semanas de trabalho
        return 4*this.salarioSemanal;
    }
    
    public String toString(){
        String a = super.toString() + "\n Salário:"+ this.ganhoSalarial();
        return a;
    }
}
