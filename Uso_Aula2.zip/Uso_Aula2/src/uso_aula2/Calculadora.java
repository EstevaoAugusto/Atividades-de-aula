package uso_aula2;

import java.util.Scanner;

public class Calculadora {
    
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        int n1,n2,r;
        int e;
        
        
                System.out.println("Digite um numero 1:");
                n1 = scanner.nextInt();
                System.out.println("Digite um numero 2:");
                n2 = scanner.nextInt();
                
                System.out.println("Escolha: \n (1)Soma \n (2)Subtração \n (3) Multiplicação:");
                e = scanner.nextInt();
          
        switch(e){
            case 1:
                r = n1 + n2;
                System.out.println(n1 +" + "+ n2 +" = "+ r);
                break;
            case 2:
                r = n1 - n2;
                System.out.println(n1 +" - "+ n2 +" = "+ r);
                break;
            case 3:
                r = n1 * n2;
                System.out.println(n1 +" * "+ n2 +" = "+ r);
                break;
        }
    }
}
