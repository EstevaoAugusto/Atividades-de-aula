package Testando;

import java.util.Scanner;

public class Calculadora extends Conteudo{
    
    
    public static void main(String[] args) {
        
        Calculadora calculo = new Calculadora();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite valor para o N1:");
        calculo.n1 = scanner.nextDouble();
        System.out.println("Digite valor para o N2:");
        calculo.n2 = scanner.nextDouble();
        
        
        
    }
}