package Interface2;


public class GerarDescricao {
    
    
    
}