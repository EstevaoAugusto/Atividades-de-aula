package Interface2;


public interface Pagamento {
    
    //interface não tem atributo
    public double calculaPagamento();
}