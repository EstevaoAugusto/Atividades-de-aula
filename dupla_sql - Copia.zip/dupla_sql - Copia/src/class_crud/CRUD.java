package class_crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class CRUD {
    
    public static void InserirFuncionario(Funcionario func) throws SQLException, ClassNotFoundException {
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Sist_EventGamer","root",""); //Lembrar de adicionar senha do SQL
        PreparedStatement pst = con.prepareStatement("INSERT INTO funcionario(id,nome,horario,salario,tipo_atributo) VALUES (?,?,?,?,?);");
        
        pst.setInt(1,func.getCod());
        pst.setString(2,func.getNome());
        pst.setInt(3,func.getHorario());//<-- Sintaxe do Horario: ano/mes/dia horas:minutos:segundos
        pst.setFloat(4,func.getSalario());
        pst.setString(5,func.getFuncao());
        
        pst.executeUpdate();
        
        pst.close();
        con.close();
    }
    
    public static Vector ListarFuncionario(int id) throws SQLException, ClassNotFoundException {
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Sist_EventGamer","root","");
        ResultSet res = con.createStatement().executeQuery("SELECT * FROM Funcionario WHERE id = "+id+";");
        Vector vet = new Vector();
        
        while(res.next()){
            vet.add(res.getInt("id"));
            vet.add(res.getString("nome"));
            vet.add(res.getInt("horario"));
            vet.add(res.getFloat("salario"));
            vet.add(res.getString("tipo_atributo"));
            
        }
        return vet;
        
        
    }
    
    public static void AtualizarFuncionario(Funcionario func) throws SQLException, ClassNotFoundException {
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Sist_EventGamer","root","");
        PreparedStatement pst = con.prepareStatement("UPDATE Funcionario SET nome = ?,horario = ?,salario = ?,tipo_atributo = ? WHERE id = ?;");
        
        pst.setString(1,func.getNome());
        pst.setInt(2,func.getHorario());
        pst.setFloat(3,func.getSalario());
        pst.setString(4,func.getFuncao());
        pst.setInt(5,func.getCod());
        
        pst.executeUpdate();
       
        pst.close();
        con.close();
    }
    
    public static void ExcluirFuncionario(Funcionario func) throws SQLException, ClassNotFoundException {
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Sist_EventGamer","root","");
        PreparedStatement pst = con.prepareStatement("DELETE FROM Funcionario WHERE id = ?;");
        
        pst.setInt(1,func.getCod());
        
        pst.executeUpdate();
       
        pst.close();
        con.close();
    }
}