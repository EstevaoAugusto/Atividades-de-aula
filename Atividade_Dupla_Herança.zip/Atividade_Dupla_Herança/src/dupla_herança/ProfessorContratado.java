package dupla_herança;

//***************************
//Instituto Federal do Sul de Minas Gerais - Campus Avançado Carmo de Minas
//Disciplina......: Linguagem de Programação I
//Turma/Curso: 2 Ano / Técnico em Informática Integrado
//Aluno...........: Gabriel de Melo Brandes
//		    Estevão Agusto da Fonseca Santos
//**
public class ProfessorContratado extends Professor{
		
	private int numeroContrato;
	public int getNumeroContrato() {
		return numeroContrato;
	}
	public void setNumeroContrato(int numeroContrato) {
		this.numeroContrato = numeroContrato;
	}
	
	public ProfessorContratado(int codigo, String nome, String area, float salario, int numeroContrato) {
		this.codigo = codigo;
		this.nome = nome;
		this.area = area;
		this.salario = salario;
		this.numeroContrato = numeroContrato;
	}
	
	@Override
	public void receberComissao() {
		this.salario = this.salario+500;
	}
	
	@Override
	public String toString() {
		String a = "\n Codigo: " +this.codigo + "\n Nome: "+this.nome+ "\n Area: "+this.area+ "\n Numero do Contrato: "+this.numeroContrato + "\n Salario: "+this.salario;
		return a;
	}
	
	public void marcarFerias(String mes) {
		if (mes.equals("Julho")) {
			System.out.println ("Férias Marcadas");
		}else {
			System.out.println ("Não é possível marcar férias neste período");
		}
	}
}