package dupla_herança;

//***************************
//Instituto Federal do Sul de Minas Gerais - Campus Avançado Carmo de Minas
//Disciplina......: Linguagem de Programação I
//Turma/Curso: 2 Ano / Técnico em Informática Integrado
//Aluno...........: Gabriel de Melo Brandes
//		    Estevão Agusto da Fonseca Santos
//**
public class ProfessorEfetivo extends Professor implements Ferias {
	
	private int siape;
	public int getSiape() {
		return siape;
	}
	public void setSiape(int siape) {
		this.siape = siape;
	}
	public ProfessorEfetivo(int codigo, String nome, String area, float salario, int siape) {
		this.codigo = codigo;
		this.nome = nome;
		this.area = area;
		this.salario = salario;
		this.siape = siape;
	}
	
	@Override
	public void receberComissao() {
		this.salario = this.salario + 1500;
	}
	
	@Override
	public String toString() {
		String a = "\n Codigo: " +this.codigo + "\n Nome: "+this.nome+ "\n Area: "+this.area+ "\n Siape: "+this.siape + "\n Salario: "+this.salario;
		return a;
	}
	
	public void marcarFerias(String mes) {
		if (mes.equals("Julho")) {
			System.out.println("Férias Marcadas");
		}else if(mes.equals ("Janeiro")) {
			System.out.println ("Férias Marcadas");
		}else {
			System.out.println ("Não é possível marcar férias neste período");
		}
	}
}