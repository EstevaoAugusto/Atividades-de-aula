package dupla_herança;

/********************************************************************************
Instituto Federal do Sul de Minas Gerais - Campus Avançado Carmo de Minas
Disciplina......: Linguagem de Programação I
Turma/Curso: 2 Ano / Técnico em Informática Integrado
Nomes dos alunos: Gabriel de Melo Brandes
                  Estevão Augusto da Fonseca Santos 
*********************************************************************************/

public interface Ferias {
    
    
    public void marcarFerias(String mes);
}