package dupla_herança;

/* ******************************************************************************
Instituto Federal do Sul de Minas Gerais - Campus Avançado Carmo de Minas
Disciplina......: Linguagem de Programação I
Turma/Curso: 2 Ano / Técnico em Informática Integrado
Nomes dos alunos: Gabriel de Melo Brandes
                  Estevão Augusto da Fonseca Santos 
*******************************************************************************/


public abstract class Professor implements Ferias{

    protected int codigo;
    protected String nome;
    protected String area;
    protected float salario;
    
    public abstract void receberComissao();
    
    @Override
    public String toString(){
        
        return "Nome: "+ this.nome +"\n"+ "Area:"+ this.area;
        
    }
}