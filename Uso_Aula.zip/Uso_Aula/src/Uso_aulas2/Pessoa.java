package Uso_aulas2;


    public class Pessoa {

        int cpf;
        
        public void setCpf(int c){
            this.cpf = c;
        }
        public int getCpf(){
            return cpf;
        }
    
    }
