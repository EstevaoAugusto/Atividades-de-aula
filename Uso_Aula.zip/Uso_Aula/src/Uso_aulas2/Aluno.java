package Uso_aulas2;


public class Aluno extends Pessoa {
    private int matricula;
    protected String nome;
    
    public int getMatricula(){
        return matricula;
    }
    public void setMatricula(int matricula){
        this.matricula = matricula;
    }
    
    
}
