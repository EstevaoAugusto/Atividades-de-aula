package Uso_aulas2;


public class Principal {
    
    
    public static void main(String[] args) {
        
        Aluno a1 = new Aluno();
        a1.setMatricula(3141);
        a1.nome = "Pedro";
        a1.setCpf(99);
        
        System.out.println("Dados do Aluno");
        System.out.println("Matricula: "+ a1.getMatricula());
        System.out.println("Nome: "+ a1.nome);
        System.out.println("CPF: "+ a1.getCpf());
    }
    
}
