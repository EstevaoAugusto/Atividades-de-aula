package Uso_aulas;


public class Livro {
    
    //encapsulamento (public ou private)
    private String nome;
    private Autor author1;
    private double preco;
    private int qtdEstoque;
    
    //metodos construtores (sobrecarga de metodos)
    public Livro(String n, Autor a, double p){
        this.nome = n;
        this.author1 = a;
        this.preco = p;
    }
    
    public Livro(String n, Autor a, double p, int qt){
        this.nome = n;
        this.author1 = a;
        this.preco = p;
        this.qtdEstoque = qt;
    }
    
    //metodos getters e setters
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setAutor(Autor a){
        this.author1 = a;
    }
    
    public void setPreco(double p){
        this.preco = p;
    }
    
    public void setQtEstoque(int qt){
        this.qtdEstoque = qt;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public double getAuthor(){
        return this.preco;
    }
    
    public Autor getAutor(){
        return this.author1;
    }
    
    public double getPreco(){
        return this.preco;
    }
    
    public int getQtEstoque(){
        return this.qtdEstoque;
    }
}
