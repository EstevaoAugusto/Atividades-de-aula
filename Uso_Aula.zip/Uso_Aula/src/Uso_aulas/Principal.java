package Uso_aulas;


public class Principal {
    
    public static void main(String[] args){
        Autor a = new Autor();
        Autor b[] = new Autor[5];
        
        
        
        a.setNome("Carlos Arbeto");
        a.setEmail("arbeto@gmail.com");
        a.setSexo('M');
        
        Livro q = new Livro("Projeto de banco de dados", a, 50.00, 10);
        
        System.out.println("Nome do Livro: " + q.getNome());
        System.out.println("Autor do Livro: " + q.getAutor());

    }
}
