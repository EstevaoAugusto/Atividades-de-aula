package Uso_aulas;


    public class Autor{
    
        private String nome;
        private String email;
        private char sexo;
        
        public void setNome(String n){
            String nome = "Juliete";
            this.nome = nome;
        }
        
        public String getNome(){
            return this.nome;
        }
        
        public void setEmail(String email){
            this.email = email;
        }
        
        public String getEmail(){
            return this.email;
        }
        
        public void setSexo(char sexo){
            this.sexo = sexo;
        }
        
        public char getSexo(){
            return this.sexo;
        }
        
        //sobreescrita do metodo ToString()
        @Override //override significa sobreescrita de metodos
        public String toString(){
            String m = "\nNome do autor " + this.getNome() +
                    "\n E-mail: " + this.getEmail() +
                    "\n Sexo:" + this.getSexo();
            
            return m;            
        }
}
