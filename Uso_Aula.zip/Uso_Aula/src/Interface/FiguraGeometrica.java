package Interface;


public interface FiguraGeometrica {
    
    public String getNomeFigura();
    public int getArea();
    public int getPerimetro();
    
}