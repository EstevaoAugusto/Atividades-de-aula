package Heranca;

import java.util.ArrayList;


public class Principal {
    
    public static void main(String[] args) {
        
        ArrayList<Professor> listaProfs = new ArrayList<Professor>();
        
        ProfessorEfetivo pe = new ProfessorEfetivo("Juliete","GH1243",20,2000);
        ProfessorHorista ph = new ProfessorHorista("João","HJ4456",25,40,55);
        ProfessorEfetivo pe2 = new ProfessorEfetivo("Joana","TH1243",29,4000);
        ProfessorHorista ph2 = new ProfessorHorista("Maria","PJ4456",28,30,60);
        
        listaProfs.add(pe);
        listaProfs.add(ph);
        listaProfs.add(pe2);
        listaProfs.add(ph2);
        
        for(int i=0; i<listaProfs.size();i++){
            if(listaProfs.get(i) instanceof ProfessorEfetivo){
                ProfessorEfetivo p1=(ProfessorEfetivo) listaProfs.get(i);
                System.out.println("Nome: "+p1.nome);
                System.out.println("Salario: "+p1.getSalario());
                System.out.println("-----------------------------");
            }
            else
            if(listaProfs.get(i) instanceof ProfessorHorista){
                ProfessorHorista p2 = (ProfessorHorista) listaProfs.get(i);
                System.out.println("Nome: "+p2.nome);
                p2.calcularSalario();
                System.out.println("-----------------------------");
            }
            //System.out.println("Nome: "+ listaProfs.get(i).getNome());
            //listaProfs.get(i).tipoProfessor();
            //System.out.println("-----------------------------");
        }
    }
    
}
