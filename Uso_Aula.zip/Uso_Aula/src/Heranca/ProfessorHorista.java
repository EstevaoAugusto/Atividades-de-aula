package Heranca;


public class ProfessorHorista extends Professor {
    
    private int total_horas;
    private float valor_hora;
    
    public ProfessorHorista(String nome, String mat, int idade, int th, float vh){
        super(nome, mat, idade);
        this.total_horas=th;
        this.valor_hora=vh;
    }
    
    public int getTotal_horas() {
        return total_horas;
    }

    public void setTotal_horas(int total_horas) {
        this.total_horas = total_horas;
    }

    public float getValor_hora() {
        return valor_hora;
    }

    public void setValor_hora(float valor_hora) {
        this.valor_hora = valor_hora;
    }
    
    @Override
    public void tipoProfessor(){
        super.tipoProfessor();
        System.out.println("Este objeto é do tipo ProfessorHorista");
    }
    
    public void calcularSalario(){
        System.out.println("Salario = "+ (this.total_horas*this.valor_hora));
    }
}
