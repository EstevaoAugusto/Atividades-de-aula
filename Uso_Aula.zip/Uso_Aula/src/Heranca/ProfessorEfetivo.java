package Heranca;


public class ProfessorEfetivo extends Professor{
    
    private float salario;
    
    public ProfessorEfetivo(){
        
    }
    
    public ProfessorEfetivo(String nome){
        super(nome);
    }
    
    public ProfessorEfetivo(String nome, String matricula, int idade, float salario){ 
        //super indica acesso a classe "Mãe", ou seja, construtor da Classe Professor
        super(nome, matricula, idade);
        if(salario>0) this.salario=salario;
    }
    
    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }
    
    //Override significa sobrescrita de metodo
    @Override
    public void tipoProfessor(){
        //o super serve para acessar qualquer metodo da classe "Mae"
        super.tipoProfessor();
        System.out.println("Neste caso, esse objeto é um Professor Efetivo");
    }
    
}