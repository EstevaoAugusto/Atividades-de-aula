package Pacote;


public class Data {
    
    protected int dia;
    protected int mes;
    protected int ano;
    
}