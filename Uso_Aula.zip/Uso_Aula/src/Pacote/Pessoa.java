package Pacote;


public abstract class Pessoa {
    
    public String nome;
    
    
    abstract void imprimeDados();
}