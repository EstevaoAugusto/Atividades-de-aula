package Poliomorfismo;


public class Carro extends Automovel{
    
    protected int qtPortas;
    
    //overload de metodos construtores na classe Carro
    public Carro(){
        
    }
    
    public Carro(int qtPortas, int c, String m){
        //indicando que vou enviar para o construtor com os
        //parametros c e m, os valores passados neste construtor
        //superclasse
        super(c,m);
        this.qtPortas = qtPortas;
    }
    
    public Carro(int qtPortas, String m){
        //
        super(m);
        this.qtPortas = qtPortas;
    }
    //Overload na propria classe
    public Carro(String m){
        this.marca = m;
    }
    //exemplo de sobrescrita de metodo entre a classe filha e a classe mãe
    
    @Override // não é obrigatório, mas interessante marcação
    public void monstrarInformacoes(){
        //System.out.println("Marca: "+ this.marca);
        super.monstrarInformacoes();
        System.out.println("Quantidade de Portas: "+ this.qtPortas);
    }
}
