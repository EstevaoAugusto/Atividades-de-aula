package Poliomorfismo;

public class Automovel {
    
    protected int codigo;
    protected String marca;
    
    public Automovel(){
        
    }
    //Overload na propria classe
    public Automovel(int c, String m){
        this.codigo = c;
        this.marca = m;
    }
    
    //Overload  na propria classe
    public Automovel(String m){
        this.marca = m;
    }
    
    //Posso ter overload em outros métodos além do construtor na própria classe
    public void monstrarInformacoes(){
        System.out.println("Marca: "+ this.marca);
    }
    
    //No overload, o nome do metodo é o mesmo, mas a assinatura é
    //obrigatoriamente diferente
    public void monstrarInformacoes(boolean teste){
        if(teste){
            System.out.println("Marca: "+ this.marca);
        }
    }
    
    //estou tentando fazer uma sobreescrita na mesma classe
    //Sobreescrita na mesma classe não pode
    /*public void monstrarInformacoes(boolean teste){
    
    }*/ 
    
    @Override
    public String toString(){
        return "String da classe Carro";
    }
}