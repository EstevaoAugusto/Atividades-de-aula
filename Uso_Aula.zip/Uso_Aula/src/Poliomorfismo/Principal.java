package Poliomorfismo;


public class Principal {
    
    public static void main(String[] args) {
        Carro c1 = new Carro();
        
        c1.codigo = 10; //herdou de automovel
        c1.marca = "Honda";//herdou de automovel
        c1.qtPortas = 4;//da classe Carro
        
        c1.monstrarInformacoes();// esta executando  o metodo herdade pelo automovel
        
        Automovel auto = new Automovel();
        auto.monstrarInformacoes();
    }
    
}