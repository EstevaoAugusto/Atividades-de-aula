package inter_graf;


public class Usuario {
    
    private String nome;
    private String senha;
    private int idade;
    private String sexo;
    
    public Usuario(String nome, String senha, int idade, String sexo){
        this.nome = nome;
        this.senha = senha;
        this.idade = idade;
        this.sexo = sexo;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    @Override
    public String toString(){
        return "Nome: " + this.nome 
                +"\n Senha: "+this.senha
                +"\n Idade: "+this.idade
                +"\n Sexo: "+this.sexo;
    }
    
}