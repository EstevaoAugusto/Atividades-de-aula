package AulaArquivo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Arquivo {
    
    public static void main(String[] args) {
        try {
            /*try {
            lerArquivoTexto();
            } catch (Exception ex) {
            ex.printStackTrace();
            }*/
            //escreverArquivo();
            lerArquivoCSV();
        } catch (IOException ex) {
            Logger.getLogger(Arquivo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static void lerArquivoTexto() throws FileNotFoundException, IOException {
        /*  1º passo -> saber o nome do arquivo
        Se o arquivo estiver na mesma pasta da classe só precisa do nome dele
        ou seja, caminho relativo;
        Se não tiver dentro da mesma pasta, eu preciso do caminho absoluto (completo)
        do arquivo
        */
        String nomeArquivo = "/home/juliete/NetBeansProjects/Aulas/src/AulaArquivo/teste.txt";
        
        /*2º Passo -> criar um objeto da Classe File
        O construtor de File requer uma string com o nome do arquivo
        */
        File file = new File(nomeArquivo);
        
        /*3º Passo -> criar um objeto da Classe FileReader
        precisa de um objeto File no construtor
        */
        FileReader fileReader = new FileReader(file);
        
        /*4º Passo -> criar um objeto da Classe BufferedReader
        precisa de um objeto FileReader no construtor
        */
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        
        /*5º passo -> percorrer o arquivo através do objeto buffer e realizar a operação
        que você deseja para o aplicativo*/
        while(bufferedReader.ready()){
            String a = bufferedReader.readLine(); //retorna a linha corrente do arquivo e pula para a próxima
            System.out.println(a+"\n");
        }
        
        /*6º passo -> fechar os arquivos*/
        bufferedReader.close();
        fileReader.close();        
    }

    private static void escreverArquivo() throws IOException {
        /*
            1º passo = nome do arquivo
            2º passo = objeto do tipo File (requer uma string com nome do arquivo no construtor)
            3º passo = objeto do tipo FileWriter (requer um objeto File no construtor)
            4º passo = objeto do tipo BufferedWriter (requer um objeto FileWriter no construtor)
        */
        String nomeArquivo = "/home/juliete/NetBeansProjects/Aulas/src/AulaArquivo/testeEscrita.txt";
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new File(nomeArquivo)));
        
        /*5º Passo -> realizar a escrita no arquivo*/
        bufferedWriter.write("Juliete Ramos\n");
        bufferedWriter.write("2º Ano de Informática\n");
        
        /*6º Passo -> fechar o buffer e liberar espaço de memória*/
        bufferedWriter.flush();
        bufferedWriter.close();
    }

    private static void lerArquivoCSV() throws FileNotFoundException, IOException {
        /*Repetir passos de 1 a 4 na leitura de Arquivos*/
        String arq = "/home/juliete/NetBeansProjects/Aulas/src/AulaArquivo/DadosDisciplinas.csv";
        File file = new File(arq);
        BufferedReader bf = new BufferedReader(new FileReader(file));
        
        //Usar a estrutura de repetição para ler todo o arquivo
        int count=0;
        while(bf.ready()){
            if(count==0){
                String cab = bf.readLine();
                System.out.println(cab);
            }else{
                //split significa dividir conteúdo de uma string por algum caracter
                String [] vetor = bf.readLine().split(";");
                System.out.println("Código: " + vetor[0]);
                System.out.println("Disciplina: " + vetor[1]);
                System.out.println("Professor: " + vetor[2]);
                System.out.println("-------------------------------------");
            }
            count++;
        }
        
        bf.close();
    }
}